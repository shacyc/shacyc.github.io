var map = null;
var popup = null;
var lines = [];

/** Icons */
var iconAnchor = [14, 14];
var userIconAnchor = [20, 0];
var iconSize = [28, 28];
var newCaseIconSize = [20, 20];


var iconLocation = 'Content/covidmap/';
if (window.location.origin === "file://" || window.location.origin === "https://shacyc.github.io") {
    iconLocation = '';
}
var Icons = {
    f0new: L.icon({ iconUrl: `${iconLocation}images/f0new.gif`, iconAnchor: iconAnchor, iconSize: newCaseIconSize }),
    f0: L.icon({ iconUrl: `${iconLocation}images/f0.svg`, iconAnchor: iconAnchor, iconSize: iconSize }),
    f1: L.icon({ iconUrl: `${iconLocation}images/f1.svg`, iconAnchor: iconAnchor, iconSize: iconSize }),
    f2: L.icon({ iconUrl: `${iconLocation}images/f2.svg`, iconAnchor: iconAnchor, iconSize: iconSize }),
    f3: L.icon({ iconUrl: `${iconLocation}images/f3.svg`, iconAnchor: iconAnchor, iconSize: iconSize }),
    f4: L.icon({ iconUrl: `${iconLocation}images/f45.svg`, iconAnchor: iconAnchor, iconSize: iconSize }),
    f5: L.icon({ iconUrl: `${iconLocation}images/f45.svg`, iconAnchor: iconAnchor, iconSize: iconSize }),
    f0dest: L.icon({ iconUrl: `${iconLocation}images/f0dest.svg`, iconAnchor: iconAnchor, iconSize: iconSize }),
    userLocation: L.icon({ iconUrl: `${iconLocation}images/userLocation.svg`, iconAnchor: userIconAnchor }),
    Vietnam: L.icon({ iconUrl: `${iconLocation}images/Vietnam.svg`, iconAnchor: userIconAnchor }),
};

/** z-index */
var MarkerZIndex = {
    f0new: 35000000,
    f0: 30000000,
    f1: 25000000,
    f2: 20000000,
    f3: 15000000,
    f4: 10000000,
    f5: 5000000,
    f0dest: 0
};

var clusterMarker = {
    f0: [],
    f1: [],
    f2: [],
    f345: [],
    f0dest: []
};

/**
 * vẽ các bệnh nhân ra
 * @param {*} patient
 */
function drawPatient(patient) {
    try {

        /** ftype */
        patient.ftype = patient.Type;
        if (patient.Type === 'f0' && patient.State === 'new-case') {
            patient.ftype = 'f0new';
        }

        /** vẽ marker bệnh nhân */
        var patientLocation = {
            lat: patient.Home.Lat,
            lng: patient.Home.Lng
        };
        var marker = L.marker(patientLocation, {
            icon: Icons[patient.ftype],
            zIndexOffset: MarkerZIndex[patient.ftype]
        });

        /** hiển thị popup thông tin chi tiết */
        marker.on("click", function() {

            /** show popup */
            showPatientPopupInfo(patient);

            /** vẽ cây liên kết của bệnh nhân */
            drawPatientTree(patient);

        });

        /** add vào cluster */
        switch (patient.ftype) {
            case "f0":
            case "f0new":
                clusterMarker.f0.push(marker);
                break;
            case "f1":
                clusterMarker.f1.push(marker);
                break;
            case "f2":
                clusterMarker.f2.push(marker);
                break;
            case "f3":
            case "f4":
            case "f5":
                clusterMarker.f345.push(marker);
                break;
        }

        /** vẽ các node con */
        patient.Relation.forEach(rel => {
            /** đường dẫn từ gốc đến node hiện tại */
            rel.Path = JSON.parse(JSON.stringify(patient.Path));
            rel.Path.push({
                Lat: patient.Home.Lat,
                Lng: patient.Home.Lng,
                Id: patient.Id
            });

            /** vẽ con */
            drawPatient(rel);
        });

        /** vẽ điểm đến của f0 */
        // if (patient.Locations && patient.Locations.length > 0) {
        //     patient.Locations.forEach(loc => {
        //         /** vẽ điểm đến */
        //         var visitLocation = {
        //             lat: loc.Lat,
        //             lng: loc.Lng
        //         };
        //         var f0VisitMarker = L.marker(visitLocation, {
        //             icon: Icons.f0dest,
        //             zIndexOffset: 0
        //         }).addTo(map);
        //         clusterMarker.f0dest.push(f0VisitMarker);

        //         /** hiển thị popup */
        //         f0VisitMarker.on("click", function() {
        //             var visitPopupContent = `<div>
        //                     <b>Thời gian:</b> ${loc.Timestamp}
        //                 </div>
        //                 <div>
        //                     <b>Địa diểm:</b> ${loc.Visits}
        //                 </div>`;

        //             popup = L.popup()
        //                 .setLatLng(visitLocation)
        //                 .setContent(visitPopupContent)
        //                 .openOn(map);
        //         });
        //     });
        // }
    } catch (error) {
        console.log(error);
    }
}

/**
 * hiển thị popup của bệnh nhân
 * @param {*} patient 
 */
function showPatientPopupInfo(patient) {
    /** các điểm đã đi qua */
    var visitDescription = buildVisitDescription(patient);

    /** show popup */
    popupContent = `
        <div style="margin-right: 16px;">
            <b>Trường hợp:</b> ${patient.Name}
        </div>
        <div>
            <b>Địa chỉ:</b> ${patient.Address}
        </div>
        ${visitDescription}`;

    /** show popup */
    popup = L.popup()
        .setLatLng(patientLocation)
        .setContent(popupContent)
        .openOn(map);
}

/**
 * vẽ cây liên kết của bệnh nhân
 * @param {*} patient 
 */
function drawPatientTree(patient) {
    /** vẽ đường tới các điểm đến */
    // if (patient.Locations && patient.Locations.length > 0) {
    //     patient.Locations.forEach(loc => {
    //         /** tọa độ điểm đến */
    //         var visitLocation = {
    //             lat: loc.Lat,
    //             lng: loc.Lng
    //         }
    //         var polyline = L.polyline([patientLocation, visitLocation], {
    //             color: '#ff6666',
    //             weight: 2,
    //             opacity: 0.5,
    //             smoothFactor: 1
    //         }).addTo(map);
    //         setTimeout(() => {
    //             polyline.bringToFront();
    //         }, 100);

    //         lines.push(polyline);
    //     });
    // }
}

/**
 * dựng lộ trình đi
 */
function buildVisitDescription(patient) {
    /** nội dung detail info */
    var visitDescription = "";
    if (patient.Locations !== null && patient.Locations.length > 0) {
        patient.Visits = "";

        patient.Locations.forEach(visited => {
            visitDescription += `${visited.Timestamp} - ${visited.Visits}<br/>`
        });

        visitDescription = `
        <div>
            <b>Lộ trình</b>
        </div>
        <div class="f0-visit-description">
            ${visitDescription}
        </div>`;

    }
    return visitDescription;
}

/**
 * draw cluster
 */
function drawCluster(ftype) {
    var cluster = new L.MarkerClusterGroup({
        showCoverageOnHover: false,
        animate: false,
        iconCreateFunction: function(cl) {
            return new L.DivIcon({
                html: `<div class="cluster ${ftype}"><div>${cl.getChildCount()}</div></div>`
            });
        }
    });

    clusterMarker[ftype].forEach(m => {
        cluster.addLayer(m);
    });

    map.addLayer(cluster);
}

/**
 * bắt đầu xử lý map
 */
function processMap() {
    /** get dữ liệu */
    var data = [];

    if (
        window.location.origin === "file://" ||
        window.location.origin === "https://shacyc.github.io"
    ) {
        data = jsData;
    } else {
        $.ajax({
            type: "GET",
            url: "/CovidMap/CovidMapTree",
            dataType: "json",
            async: false,
            success: function(response) {
                data = response;
            },
            error: function() {
                console.log("Không lấy được dữ liệu từ Api.");
            }
        });
    }

    data.forEach(patient => {
        /** nút gốc thì đường dẫn cha của nó = [] */
        patient.Path = [];
        /** vẽ các f */
        drawPatient(patient);
    });

    /** vẽ các điểm ra */
    drawPoints(clusterMarker.f0dest);
    drawPoints(clusterMarker.f345);
    drawPoints(clusterMarker.f2);
    drawPoints(clusterMarker.f1);
    drawPoints(clusterMarker.f0);
}

/**
 * vẽ các điểm ra
 */
function drawPoints(cluster) {
    cluster.forEach(m => {
        m.addTo(map);
    });
}

/**
 * click map event
 */
function mapClickEvent() {
    /** xóa hết các đường line */
    lines.forEach(line => {
        line.remove();
    });
    lines = [];
}

/**
 * custom map: thêm Hoàng Sa, Trường Sa
 */
function customMap() {
    var HSTS = [
        { lat: 16.531174, lng: 111.611804, title: 'Quần đảo Hoàng Sa' },
        { lat: 10.767119, lng: 115.825618, title: 'Quần đảo Trường Sa' },

    ];
    HSTS.map((qd) => {

        var html = `
        <div class="vietnam">
          <div>${qd.title}</div>
        </div>
        `;

        L.marker({ lat: qd.lat, lng: qd.lng }, {
            icon: new L.DivIcon({
                className: "",
                html: html
            })
        }).addTo(map);
    });

    /** biển đông */
    L.marker({ lat: 12.483703, lng: 114.038648 }, {
        icon: new L.DivIcon({
            className: "",
            html: '<div class="vietnam">Biển Đông</div>'
        })
    }).addTo(map);
}

/**
 * init map
 */
function initMap() {
    var center = { lat: 21.0012406, lng: 105.7938073 };
    var zoom = 12;
    var userLocation = null;

    /** lấy location user từ trên url */
    try {
        var url = new URL(window.location.href);
        var lat = url.searchParams.get("lat");
        var lng = url.searchParams.get("lon");
        // lat = 21.027794;
        // lng = 105.852263;
        if (lat && lng) {
            userLocation = { lat: parseFloat(lat), lng: parseFloat(lng) };
            zoom = 15;
        }
    } catch (error) {
        console.log("Lấy location của user bị lỗi.");
    }

    map = L.map("map", {}).setView(userLocation ? userLocation : center, zoom);

    /** get token from mapbox.com */
    var token = "pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw";
    // var token = "pk.eyJ1Ijoic2hhY3ljIiwiYSI6ImNrODFjeWxqNzBuaDgzZW80eWFyOWZ5aDQifQ.sPH-TcTHklGpF-GYFL7oZQ";
    // L.tileLayer(
    //     `https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=${token}`, {
    //         maxZoom: 18,
    //         attribution: '&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> ' +
    //             '<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
    //             '<a href="https://www.mapbox.com/">Mapbox</a>',
    //         id: "mapbox/streets-v11",
    //         tileSize: 512,
    //         zoomOffset: -1
    //     }
    // ).addTo(map);

    // https://tiles.maps.elastic.co/styles/osm-bright-desaturated/{z}/{x}/{y}.png?elastic_tile_service_tos=agree&my_app_name=kibana&my_app_version=7.6.1&license=b823c5ff-8c0c-4c41-8350-988eff1d81b6

    // L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    //     attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    // }).addTo(map);

    // L.tileLayer('https://tiles.maps.elastic.co/styles/osm-bright-desaturated/{z}/{x}/{y}.png?elastic_tile_service_tos=agree&my_app_name=kibana&my_app_version=7.6.1&license=b823c5ff-8c0c-4c41-8350-988eff1d81b6', {
    //     attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    // }).addTo(map);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    }).addTo(map);

    /** vẽ vị trí user */
    if (userLocation) {
        L.marker(userLocation, { icon: Icons.userLocation }).bindPopup('Bạn đang ở đây').addTo(map);
    }

    /** custom map */
    customMap();

    /** map event */
    map.on('click', mapClickEvent)

    /** bắt đầu đổ dữ liệu vào map */
    processMap();
}

window.onload = function() {
    initMap();
};